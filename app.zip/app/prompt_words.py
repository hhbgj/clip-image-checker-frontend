PROMPT_DICT = {
    "Normal": [
        "a person reading a book",
        "a cat sleeping on the couch",
        "a child playing in the park",
        "a man walking on a street",
        "a dog running on grass",
        "a teacher in a classroom",
        "a woman using a laptop",
        "a group of friends taking a selfie"
    ],
    "Porn": [
        "a naked person",
        "a pornographic sex scene",
        "graphic adult content",
        "a couple having sex",
        "explicit nudity",
        "nude woman on bed",
        "erotic scene in bedroom",
        "two naked people"
    ],
    "Terrorism": [
        "a terrorist holding a gun",
        "a bomb explosion in public",
        "a man with a suicide vest",
        "a person pointing a gun",
        "hostage situation in building"
    ],
    "Violence": [
        "a bloody fight",
        "a dead body on the ground",
        "a man covered in blood",
        "a crime scene with blood",
        "a violent street protest"
    ]
}
