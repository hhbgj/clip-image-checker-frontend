import torch
import clip
from .model_loader import model, preprocess, device
from .prompt_words import PROMPT_DICT

def predict(image):
    image_input = preprocess(image).unsqueeze(0).to(device)

    # 拼装提示词 + 标签索引
    text_prompts = []
    class_map = []
    for label, prompts in PROMPT_DICT.items():
        text_prompts.extend(prompts)
        class_map.extend([label] * len(prompts))

    text_inputs = clip.tokenize(text_prompts).to(device)

    with torch.no_grad():
        image_features = model.encode_image(image_input)
        text_features = model.encode_text(text_inputs)

    image_features /= image_features.norm(dim=-1, keepdim=True)
    text_features /= text_features.norm(dim=-1, keepdim=True)

    similarity = (image_features @ text_features.T).squeeze(0)
    max_score, max_idx = similarity.max(0)
    score = float(max_score.item()) * 100
    matched_label = class_map[max_idx]

    result = 1 if matched_label != "Normal" and score >= 70 else 0

    return {
        "result": result,
        "score": int(score),
        "label": matched_label
    }
