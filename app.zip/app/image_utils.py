from PIL import Image
import requests
from io import BytesIO

def load_image_from_url(url: str) -> Image.Image:
    try:
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Referer": url
        }
        response = requests.get(url, headers=headers, timeout=5)
        response.raise_for_status()
        return Image.open(BytesIO(response.content)).convert("RGB")
    except Exception as e:
        raise ValueError(f"无法加载URL图片: {str(e)}")

def load_image_from_file(file_bytes: bytes) -> Image.Image:
    try:
        return Image.open(BytesIO(file_bytes)).convert("RGB")
    except Exception as e:
        raise ValueError(f"本地图片格式错误或损坏: {str(e)}")
